# FloodSense — Full-Stack Prototype (Team ZYRO, PS11)

Hyperlocal urban flood early warning: street-level, predictive, real-time.

## Architecture
```
[Browser frontend]  <-- WebSocket + REST (JSON) -->  [FastAPI backend]
  Next.js-style map                                   Python risk engine
  (plain HTML demo)                                   40 simulated streets
                                                      alert threshold logic
```

## Run it
```bash
# 1. Backend
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000

# 2. Frontend — just open frontend/index.html in a browser
#    (or: python -m http.server 8080  inside frontend/, then visit localhost:8080)
```

The header shows **BACKEND LIVE** when connected to FastAPI, otherwise it
auto-falls back to an in-browser simulation so the demo never breaks.

## API
| Method | Endpoint            | Purpose                              |
|--------|---------------------|--------------------------------------|
| WS     | /ws                 | Live state broadcast every 1s        |
| GET    | /api/streets        | Snapshot of all 40 streets           |
| GET    | /api/streets/{id}   | One street                           |
| POST   | /api/scenario       | Set weather: dry/monsoon/cloudburst  |
| POST   | /api/threshold      | Tune alert threshold (40–90)         |
| POST   | /api/report         | Citizen flood report                 |
| GET    | /docs               | Auto-generated Swagger UI            |

## Demo script (3 min)
1. Start backend, open frontend — point out "BACKEND LIVE".
2. ⛈️ Cloudburst: watch low-elevation streets (river basin, rows 3–4) flip red.
3. Show alert feed firing + citizen "My street" warning.
4. 🛡️ Authority view: gauges, rainfall stream.
5. Drag threshold slider to 50 → more alerts (false-alarm tuning).
6. 📍 Report flooding → citizen data enters the model.
7. ☀️ Dry → streets recover, "risk subsiding" alerts.
