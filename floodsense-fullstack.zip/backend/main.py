
"""
FloodSense Backend — Hyperlocal Urban Flood Early Warning System (Prototype)
Team ZYRO · PS11

Run:  uvicorn main:app --reload --port 8000
"""
import asyncio, random, time
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="FloodSense API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ---------------- STREET NETWORK ----------------
NAMES = ["Anna Salai","GST Road","OMR","ECR","Mount Rd","Poonamallee","Avadi Rd","Velachery",
         "T Nagar","Mylapore","Adyar","Guindy","Porur","Kolathur","Perambur","Tambaram",
         "Sholinganallur","Nungambakkam","Kilpauk","Egmore","Triplicane","Royapuram","Madhavaram",
         "Ambattur","Valasaravakkam","Alwarpet","Mandaveli","Saidapet","Chromepet","Pallavaram",
         "Medavakkam","Madipakkam","Pallikaranai","Perungudi","Thoraipakkam","Karapakkam","Injambakkam",
         "Besant","Thiruvanmiyur","Kotturpuram"]

streets = []
for i, name in enumerate(NAMES):
    row, col = divmod(i, 8)
    # river basin: rows 2-3 are low-lying (like the Adyar basin)
    elev = 8 + random.random()*22 - (14 if 2 <= row <= 3 else 0) - (6 if row == 4 else 0)
    streets.append({
        "id": i, "name": f"{name} St {i+1}", "row": row, "col": col,
        "elev": round(max(1.0, elev), 1),
        "water": 0.0, "risk": 0.0, "alertState": False,
    })

# ---------------- STATE ----------------
SCENARIOS = {"dry": {"base": 0, "vol": 0},
             "monsoon": {"base": 18, "vol": 10},
             "cloudburst": {"base": 55, "vol": 35}}
state = {"scenario": "cloudburst", "threshold": 70, "rain": 0.0,
         "alertCount": 0, "started": time.time()}

class ScenarioIn(BaseModel):
    scenario: str
class ThresholdIn(BaseModel):
    value: int
class ReportIn(BaseModel):
    street_id: int
    note: str = "Citizen reported waterlogging"

# ---------------- RISK MODEL ----------------
def compute_tick():
    sc = SCENARIOS.get(state["scenario"], SCENARIOS["cloudburst"])
    state["rain"] = max(0.0, sc["base"] + (random.random() - .45) * sc["vol"]
                        + (40 if state["scenario"] == "cloudburst" and random.random() < .06 else 0))
    alerts = []
    th = state["threshold"]
    for s in streets:
        inflow = state["rain"] * (1.2 - s["elev"] / 40)
        drain = s["elev"] * .35 + s["water"] * .08
        s["water"] = max(0.0, s["water"] + (inflow - drain) * .12)
        s["risk"] = round(min(100, max(0, s["water"]*9 + state["rain"]*.35 - s["elev"]*.5)), 1)
        if s["risk"] >= th and not s["alertState"]:
            s["alertState"] = True
            state["alertCount"] += 1
            alerts.append({"type": "high", "title": f"🚨 {s['name']}",
                           "msg": f"Flood risk {int(s['risk'])}/100 — water level rising. Avoid area."})
        elif s["alertState"] and s["risk"] < th * .8:
            s["alertState"] = False
            alerts.append({"type": "info", "title": f"✅ {s['name']}", "msg": "Risk subsiding. Street reopened."})
    return alerts

# ---------------- WEBSOCKET BROADCAST ----------------
clients = set()

async def broadcast(payload):
    dead = []
    for ws in clients:
        try:
            await ws.send_json(payload)
        except Exception:
            dead.append(ws)
    for ws in dead:
        clients.discard(ws)

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    clients.add(ws)
    await ws.send_json(snapshot())
    try:
        while True:
            await ws.receive_text()  # keepalive; client pings
            await ws.send_json(snapshot())
    except WebSocketDisconnect:
        clients.discard(ws)

def snapshot():
    high = sum(1 for s in streets if s["risk"] >= state["threshold"])
    med = sum(1 for s in streets if state["threshold"]*.6 <= s["risk"] < state["threshold"])
    return {"type": "state", "time": time.strftime("%H:%M:%S"),
            "scenario": state["scenario"], "threshold": state["threshold"],
            "rain": round(state["rain"], 1), "high": high, "med": med,
            "alertCount": state["alertCount"],
            "streets": [{k: s[k] for k in ("id","name","row","col","elev","water","risk","alertState")} for s in streets]}

@app.on_event("startup")
async def simulation_loop():
    async def loop():
        while True:
            alerts = compute_tick()
            if clients:
                payload = snapshot()
                payload["alerts"] = alerts
                await broadcast(payload)
            await asyncio.sleep(1)
    asyncio.create_task(loop())

# ---------------- REST API ----------------
@app.get("/api/streets")
def get_streets():
    return snapshot()

@app.get("/api/streets/{sid}")
def get_street(sid: int):
    return next((s for s in streets if s["id"] == sid), {"error": "not found"})

@app.post("/api/scenario")
def set_scenario(body: ScenarioIn):
    if body.scenario in SCENARIOS:
        state["scenario"] = body.scenario
        return {"ok": True, "scenario": body.scenario}
    return {"ok": False, "error": "unknown scenario"}

@app.post("/api/threshold")
def set_threshold(body: ThresholdIn):
    state["threshold"] = max(40, min(90, body.value))
    return {"ok": True, "threshold": state["threshold"]}

@app.post("/api/report")
def citizen_report(body: ReportIn):
    s = next((x for x in streets if x["id"] == body.street_id), None)
    if not s:
        return {"ok": False, "error": "unknown street"}
    s["water"] += 3.5
    return {"ok": True, "street": s["name"], "msg": body.note}
